  <!-- 404 Error Text -->

<div class="container-fluid">   
<div class="text-center">
<div class="error mx-auto" data-text="404">Expired!</div>
<p class="lead text-gray-800 mb-5">Toke had expired</p>
<p class="text-gray-500 mb-0">Please request another password reset.</p>
<a href="<?php echo site_url('forgot-password')?>">&larr; Request Password Reset</a>
</div>